@extends('layouts.master')

@section('content')

    
    
  
<div class="panel panel-default">
 <div class="panel-heading " style="">
<font color="#00002B"><h4> Task List </h4> </font>
 </div>
  <div class="panel-body">
  @if(Session::has('flash_message'))
        <div class="alert alert-success fade in">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            {{ Session::get('flash_message') }}
        </div>
    @endif
<table class="table table-hover">
        <tr><th>Title</th><th>Description</th><th>Action</th></tr>
    @foreach($tasks as $task)
    
        <tr><td>{{ $task->title }}</td><td>{{ $task->description}} </td><td>
<div class="dropdown">
  <button class="dropbtn btn-link">Option</button>
  <div class="dropdown-content">
   
    <a href="{{ route('tasks.edit', $task->id) }}">Update</a>
    <a href="{{ route('tasks.destroy', $task->id) }}">Delete</a>
  </div>
</div> </td></tr>

    @endforeach
    </table>
 </div>
 <div class="panel-footer"> 


 </div>
</div>
<br><br><br><br><br><br>  

@stop