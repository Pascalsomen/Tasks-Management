<?php $__env->startSection('content'); ?>

    
    
  
<div class="panel panel-default">
 <div class="panel-heading " style="">
<font color="#00002B"><h4> Task List </h4> </font>
 </div>
  <div class="panel-body">
  <?php if(Session::has('flash_message')): ?>
        <div class="alert alert-success fade in">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo e(Session::get('flash_message')); ?>

        </div>
    <?php endif; ?>
<table class="table table-hover">
        <tr><th>Title</th><th>Description</th><th>Action</th></tr>
    <?php foreach($tasks as $task): ?>
    
        <tr><td><?php echo e($task->title); ?></td><td><?php echo e($task->description); ?> </td><td>
<div class="dropdown">
  <button class="dropbtn btn-link">Option</button>
  <div class="dropdown-content">
   
    <a href="<?php echo e(route('tasks.edit', $task->id)); ?>">Update</a>
    <a href="<?php echo e(route('tasks.destroy', $task->id)); ?>">Delete</a>
  </div>
</div> </td></tr>

    <?php endforeach; ?>
    </table>
 </div>
 <div class="panel-footer"> 


 </div>
</div>
<br><br><br><br><br><br>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>