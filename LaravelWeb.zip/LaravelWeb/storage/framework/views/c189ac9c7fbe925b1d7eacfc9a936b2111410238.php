<?php $__env->startSection('content'); ?>

    
    
    <hr>
    <div class="panel panel-default">
 <div class="panel-heading " style="background-color:#045F68;">
<font color="white"><h4>New task</h4></font>
 </div>
  <div class="panel-body">
 <?php echo Form::open([
        'route' => 'tasks.store'
    ]); ?>


    <div class="form-group <?php if($errors->get('title')): ?>: has-error <?php endif; ?>">
        <?php echo Form::label('title', 'Title:', ['class' => 'control-label']); ?>

        <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

        <?php if($errors->has('title')): ?>
            <p class="help-block"><?php echo e($errors->first('title')); ?></p>
        <?php endif; ?>
    </div>

    <div class="form-group <?php if($errors->get('description')): ?>: has-error <?php endif; ?>">
        <?php echo Form::label('description', 'Description:', ['class' => 'control-label']); ?>

        <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

        <?php if($errors->has('description')): ?>
            <p class="help-block"><?php echo e($errors->first('description')); ?></p>
        <?php endif; ?>
    </div>

    
 </div>
 <div class="panel-footer"><center>
 <?php echo Form::submit('Save task', ['class' => 'btn btn-success']); ?>


    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?> </div>
</div>

   
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>