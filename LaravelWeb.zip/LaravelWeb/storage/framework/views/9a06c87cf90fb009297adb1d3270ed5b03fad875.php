<?php $__env->startSection('content'); ?>

    

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
 <div class="panel-heading " style="background-color:#045F68;">
<font color="white"><h4>Selected Task</h4></font>
 </div>
  <div class="panel-body">
    <h2><u> Task Title:</h2></u><br>
    <h3><?php echo e($task->title); ?></h3>
     <h2><u> Task Desc:</h2></u><br>
   <h3><?php echo e($task->description); ?></h3>
    <hr>

 </div>
 <div class="panel-footer">
            <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="btn btn-primary">Edit Task</a>
             <div class="pull-right"> 
            <?php echo Form::open([
                'method' => 'DELETE',
                'route' => ['tasks.destroy', $task->id]
            ]); ?>

            <?php echo Form::submit('Delete this task', ['class' => 'btn btn-danger']); ?>

            <?php echo Form::close(); ?>

        </div>
        </div>
       
</div>
            
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>